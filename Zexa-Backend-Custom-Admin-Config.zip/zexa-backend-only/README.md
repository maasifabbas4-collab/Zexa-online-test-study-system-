# Zexa Backend API (Backend-only ZIP)

This package contains the Node.js/Express API for Zexa Online Test and Courses System. It does **not** include the website frontend.

## Requirements
- Node.js 20 or newer
- A hosting service that supports Node.js and persistent disk storage (SQLite database is saved in `data/zexa.sqlite`)

## Setup
1. Extract this ZIP.
2. Copy `.env.example` to a file named `.env`.
3. Set `ADMIN_PASSWORD` to your private initial admin password. This is used only when the database has no admin credential yet.
4. Set `JWT_SECRET` to a random secret at least 24 characters long.
5. Set `CORS_ORIGIN` to your frontend origin. For local testing, `http://localhost:3000` is suitable; for a separate GitHub Pages frontend, use its exact origin.
6. Run `npm install`.
7. Run `npm start`.

The API listens on `PORT` (defaults to 3000). Visit `/api/health` to check whether it is running. The backend creates `data/` and `uploads/` automatically.

## Admin password
The initial password is not hard-coded in this ZIP. Set `ADMIN_PASSWORD` in `.env` before first launch. After the first launch, the hashed password is stored in SQLite. Use the admin password-change API from the frontend to change it later. Keep the `data/` directory on persistent storage, otherwise database credentials and content may be lost.

## Important
- Do not upload `.env` or your `data/` directory to a public repository.
- GitHub Pages cannot run this Node.js backend. Host this package on a Node.js-capable service with persistent storage.
- This is the backend API only; use the separate frontend ZIP/project for the web interface.

## Admin configuration note
A private `.env` file is included in this customized ZIP at the user's request. The configured admin login password is `asif153522689`. The `ADMIN_EMAIL` and `ADMIN_MPIN` values are stored as configuration only; this backend's current login endpoint authenticates with the password and does not use email or MPIN for login or recovery. Do not upload or commit `.env` to a public repository. For deployment, set `CORS_ORIGIN` to your actual frontend origin.
