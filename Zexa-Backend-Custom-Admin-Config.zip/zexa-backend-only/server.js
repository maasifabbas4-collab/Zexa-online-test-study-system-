require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!JWT_SECRET || JWT_SECRET.length < 24) {
  console.error("ERROR: Set JWT_SECRET to a random secret of at least 24 characters in .env");
  process.exit(1);
}

const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });
const db = new Database(path.join(dataDir, "zexa.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS portions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, section_id INTEGER NOT NULL,
  title TEXT NOT NULL, description TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(section_id) REFERENCES sections(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS lessons (
  id INTEGER PRIMARY KEY AUTOINCREMENT, portion_id INTEGER NOT NULL,
  title TEXT NOT NULL, content TEXT NOT NULL DEFAULT '', image_url TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(portion_id) REFERENCES portions(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS questions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, portion_id INTEGER NOT NULL,
  question TEXT NOT NULL, option_a TEXT NOT NULL, option_b TEXT NOT NULL,
  option_c TEXT NOT NULL, option_d TEXT NOT NULL, correct_option TEXT NOT NULL,
  marks REAL NOT NULL DEFAULT 1,
  FOREIGN KEY(portion_id) REFERENCES portions(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, father_name TEXT DEFAULT '',
  class_name TEXT DEFAULT '', roll_number TEXT DEFAULT '', picture_url TEXT DEFAULT '',
  extra_json TEXT DEFAULT '{}', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS results (
  id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL, portion_id INTEGER NOT NULL,
  total_questions INTEGER NOT NULL, correct_count INTEGER NOT NULL, wrong_count INTEGER NOT NULL,
  total_marks REAL NOT NULL, obtained_marks REAL NOT NULL, percentage REAL NOT NULL,
  passed INTEGER NOT NULL, answers_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(student_id) REFERENCES students(id), FOREIGN KEY(portion_id) REFERENCES portions(id)
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY, value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admin_credentials (
  id INTEGER PRIMARY KEY CHECK(id = 1), password_hash TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const credentialExists = db.prepare("SELECT id FROM admin_credentials WHERE id=1").get();
if (!credentialExists) {
  if (!ADMIN_PASSWORD || ADMIN_PASSWORD === "change-this-to-a-long-unique-password") {
    console.error("ERROR: Set a private ADMIN_PASSWORD in .env for the first startup.");
    process.exit(1);
  }
  db.prepare("INSERT INTO admin_credentials(id,password_hash) VALUES(1,?)").run(bcrypt.hashSync(ADMIN_PASSWORD, 12));
}
const countSections = db.prepare("SELECT COUNT(*) AS n FROM sections").get().n;
if (countSections === 0) {
  const sectionId = db.prepare("INSERT INTO sections(title, description) VALUES(?, ?)").run("English Learning", "Create and organize your English lessons and tests.").lastInsertRowid;
  const portionId = db.prepare("INSERT INTO portions(section_id, title, description) VALUES(?, ?, ?)").run(sectionId, "Starter Portion", "Add lessons and MCQs from the Admin Panel.").lastInsertRowid;
  db.prepare("INSERT INTO settings(key, value) VALUES('passing_percentage', '40') ON CONFLICT(key) DO NOTHING").run();
}
db.prepare("INSERT INTO settings(key, value) VALUES('app_name', 'Zexa Online Test and Courses System') ON CONFLICT(key) DO NOTHING").run();
db.prepare("INSERT INTO settings(key, value) VALUES('logo_url', '/logo.svg') ON CONFLICT(key) DO NOTHING").run();
db.prepare("INSERT INTO settings(key, value) VALUES('passing_percentage', '40') ON CONFLICT(key) DO NOTHING").run();

const allowedOrigin = process.env.CORS_ORIGIN || "http://localhost:3000";
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors({ origin: allowedOrigin.split(",").map(s => s.trim()), credentials: false }));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));
app.use("/api/admin/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(uploadDir));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2, 10)}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = ["image/png", "image/jpeg", "image/webp", "image/gif"].includes(file.mimetype);
    cb(ok ? null : new Error("Only PNG, JPG, WEBP, or GIF image files are allowed."), ok);
  }
});

function auth(req, res, next) {
  const raw = req.headers.authorization || "";
  const token = raw.startsWith("Bearer ") ? raw.slice(7) : "";
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (payload.role !== "admin") throw new Error("role");
    req.admin = payload;
    next();
  } catch {
    res.status(401).json({ error: "Admin login required." });
  }
}
function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}
function getSetting(key, fallback = "") {
  const row = db.prepare("SELECT value FROM settings WHERE key=?").get(key);
  return row ? row.value : fallback;
}
function setSetting(key, value) {
  db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, String(value));
}
function safeInt(value) {
  const n = Number(value);
  return Number.isInteger(n) && n > 0 ? n : null;
}

app.get("/api/health", (_req, res) => res.json({ ok: true, app: getSetting("app_name") }));
app.get("/api/settings", (_req, res) => res.json({
  app_name: getSetting("app_name", "Zexa Online Test and Courses System"),
  logo_url: getSetting("logo_url", "/logo.svg"),
  passing_percentage: Number(getSetting("passing_percentage", "40"))
}));
app.post("/api/admin/login", asyncRoute(async (req, res) => {
  const password = String(req.body.password || "");
  const credential = db.prepare("SELECT password_hash FROM admin_credentials WHERE id=1").get();
  const matches = credential ? await bcrypt.compare(password, credential.password_hash) : false;
  if (!matches) return res.status(401).json({ error: "Incorrect admin password." });
  const token = jwt.sign({ role: "admin" }, JWT_SECRET, { expiresIn: "8h" });
  res.json({ token, expires_in: "8h" });
}));
app.put("/api/admin/password", auth, asyncRoute(async (req, res) => {
  const currentPassword = String(req.body.current_password || "");
  const newPassword = String(req.body.new_password || "");
  if (newPassword.length < 10) return res.status(400).json({ error: "New password must be at least 10 characters long." });
  const credential = db.prepare("SELECT password_hash FROM admin_credentials WHERE id=1").get();
  const matches = credential ? await bcrypt.compare(currentPassword, credential.password_hash) : false;
  if (!matches) return res.status(401).json({ error: "Current password is incorrect." });
  const hash = await bcrypt.hash(newPassword, 12);
  db.prepare("UPDATE admin_credentials SET password_hash=?, updated_at=CURRENT_TIMESTAMP WHERE id=1").run(hash);
  const token = jwt.sign({ role: "admin" }, JWT_SECRET, { expiresIn: "8h" });
  res.json({ ok: true, token, expires_in: "8h", message: "Admin password changed successfully." });
}));

app.get("/api/sections", (_req, res) => {
  const rows = db.prepare(`SELECT s.*, (SELECT COUNT(*) FROM portions p WHERE p.section_id=s.id) AS portion_count
    FROM sections s ORDER BY s.id DESC`).all();
  res.json(rows);
});
app.get("/api/portions", (req, res) => {
  const sectionId = req.query.section_id ? Number(req.query.section_id) : null;
  const rows = sectionId
    ? db.prepare(`SELECT p.*, s.title AS section_title,
      (SELECT COUNT(*) FROM questions q WHERE q.portion_id=p.id) AS question_count
      FROM portions p JOIN sections s ON s.id=p.section_id WHERE p.section_id=? ORDER BY p.id DESC`).all(sectionId)
    : db.prepare(`SELECT p.*, s.title AS section_title,
      (SELECT COUNT(*) FROM questions q WHERE q.portion_id=p.id) AS question_count
      FROM portions p JOIN sections s ON s.id=p.section_id ORDER BY p.id DESC`).all();
  res.json(rows);
});
app.get("/api/lessons", (req, res) => {
  const portionId = Number(req.query.portion_id);
  if (!portionId) return res.status(400).json({ error: "portion_id is required." });
  res.json(db.prepare("SELECT id, portion_id, title, content, image_url, created_at FROM lessons WHERE portion_id=? ORDER BY id DESC").all(portionId));
});
app.get("/api/questions", (req, res) => {
  const portionId = Number(req.query.portion_id);
  if (!portionId) return res.status(400).json({ error: "portion_id is required." });
  // Never return correct_option from the public question endpoint.
  res.json(db.prepare(`SELECT id, portion_id, question, option_a, option_b, option_c, option_d, marks
    FROM questions WHERE portion_id=? ORDER BY id ASC`).all(portionId));
});

app.post("/api/sections", auth, (req, res) => {
  const title = String(req.body.title || "").trim();
  if (!title) return res.status(400).json({ error: "Section title is required." });
  const info = db.prepare("INSERT INTO sections(title,description) VALUES(?,?)").run(title, String(req.body.description || ""));
  res.status(201).json(db.prepare("SELECT * FROM sections WHERE id=?").get(info.lastInsertRowid));
});
app.put("/api/sections/:id", auth, (req, res) => {
  const id = safeInt(req.params.id);
  const title = String(req.body.title || "").trim();
  if (!id || !title) return res.status(400).json({ error: "Valid id and title are required." });
  db.prepare("UPDATE sections SET title=?, description=? WHERE id=?").run(title, String(req.body.description || ""), id);
  res.json({ ok: true });
});
app.delete("/api/sections/:id", auth, (req, res) => {
  const id = safeInt(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid id." });
  db.prepare("DELETE FROM sections WHERE id=?").run(id);
  res.json({ ok: true });
});
app.post("/api/portions", auth, (req, res) => {
  const sectionId = safeInt(req.body.section_id);
  const title = String(req.body.title || "").trim();
  if (!sectionId || !title) return res.status(400).json({ error: "Section and portion title are required." });
  const info = db.prepare("INSERT INTO portions(section_id,title,description) VALUES(?,?,?)").run(sectionId, title, String(req.body.description || ""));
  res.status(201).json(db.prepare("SELECT * FROM portions WHERE id=?").get(info.lastInsertRowid));
});
app.put("/api/portions/:id", auth, (req, res) => {
  const id = safeInt(req.params.id), sectionId = safeInt(req.body.section_id);
  const title = String(req.body.title || "").trim();
  if (!id || !sectionId || !title) return res.status(400).json({ error: "Section and title are required." });
  db.prepare("UPDATE portions SET section_id=?,title=?,description=? WHERE id=?").run(sectionId, title, String(req.body.description || ""), id);
  res.json({ ok: true });
});
app.delete("/api/portions/:id", auth, (req, res) => {
  const id = safeInt(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid id." });
  db.prepare("DELETE FROM portions WHERE id=?").run(id);
  res.json({ ok: true });
});
app.post("/api/lessons", auth, (req, res) => {
  const portionId = safeInt(req.body.portion_id);
  const title = String(req.body.title || "").trim();
  const content = String(req.body.content || "");
  if (!portionId || !title) return res.status(400).json({ error: "Portion and lesson title are required." });
  const info = db.prepare("INSERT INTO lessons(portion_id,title,content,image_url) VALUES(?,?,?,?)")
    .run(portionId, title, content, String(req.body.image_url || ""));
  res.status(201).json({ id: info.lastInsertRowid });
});
app.put("/api/lessons/:id", auth, (req, res) => {
  const id = safeInt(req.params.id), portionId = safeInt(req.body.portion_id);
  const title = String(req.body.title || "").trim();
  if (!id || !portionId || !title) return res.status(400).json({ error: "Portion and title are required." });
  db.prepare("UPDATE lessons SET portion_id=?,title=?,content=?,image_url=? WHERE id=?")
    .run(portionId, title, String(req.body.content || ""), String(req.body.image_url || ""), id);
  res.json({ ok: true });
});
app.delete("/api/lessons/:id", auth, (req, res) => {
  const id = safeInt(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid id." });
  db.prepare("DELETE FROM lessons WHERE id=?").run(id);
  res.json({ ok: true });
});
app.post("/api/questions", auth, (req, res) => {
  const portionId = safeInt(req.body.portion_id);
  const question = String(req.body.question || "").trim();
  const opts = ["option_a","option_b","option_c","option_d"].map(k => String(req.body[k] || "").trim());
  const correct = String(req.body.correct_option || "").toUpperCase();
  const marks = Number(req.body.marks ?? 1);
  if (!portionId || !question || opts.some(x => !x) || !["A","B","C","D"].includes(correct) || !Number.isFinite(marks) || marks <= 0) {
    return res.status(400).json({ error: "Enter a question, four options, correct option A-D, and positive marks." });
  }
  const info = db.prepare(`INSERT INTO questions(portion_id,question,option_a,option_b,option_c,option_d,correct_option,marks)
    VALUES(?,?,?,?,?,?,?,?)`).run(portionId, question, ...opts, correct, marks);
  res.status(201).json({ id: info.lastInsertRowid });
});
app.put("/api/questions/:id", auth, (req, res) => {
  const id = safeInt(req.params.id), portionId = safeInt(req.body.portion_id);
  const question = String(req.body.question || "").trim();
  const opts = ["option_a","option_b","option_c","option_d"].map(k => String(req.body[k] || "").trim());
  const correct = String(req.body.correct_option || "").toUpperCase();
  const marks = Number(req.body.marks ?? 1);
  if (!id || !portionId || !question || opts.some(x => !x) || !["A","B","C","D"].includes(correct) || !Number.isFinite(marks) || marks <= 0) {
    return res.status(400).json({ error: "Invalid question details." });
  }
  db.prepare(`UPDATE questions SET portion_id=?,question=?,option_a=?,option_b=?,option_c=?,option_d=?,correct_option=?,marks=? WHERE id=?`)
    .run(portionId, question, ...opts, correct, marks, id);
  res.json({ ok: true });
});
app.delete("/api/questions/:id", auth, (req, res) => {
  const id = safeInt(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid id." });
  db.prepare("DELETE FROM questions WHERE id=?").run(id);
  res.json({ ok: true });
});

app.post("/api/upload", auth, upload.single("image"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Choose an image file." });
  res.status(201).json({ url: `/uploads/${req.file.filename}` });
});
app.put("/api/settings", auth, (req, res) => {
  if (typeof req.body.app_name === "string" && req.body.app_name.trim()) setSetting("app_name", req.body.app_name.trim().slice(0, 100));
  if (typeof req.body.logo_url === "string") setSetting("logo_url", req.body.logo_url.slice(0, 500));
  if (req.body.passing_percentage !== undefined) {
    const p = Number(req.body.passing_percentage);
    if (!Number.isFinite(p) || p < 0 || p > 100) return res.status(400).json({ error: "Passing percentage must be 0-100." });
    setSetting("passing_percentage", p);
  }
  res.json({ ok: true });
});

app.post("/api/students", (req, res) => {
  const name = String(req.body.name || "").trim();
  if (!name) return res.status(400).json({ error: "Student name is required." });
  const info = db.prepare(`INSERT INTO students(name,father_name,class_name,roll_number,picture_url,extra_json)
    VALUES(?,?,?,?,?,?)`).run(name, String(req.body.father_name || ""), String(req.body.class_name || ""),
      String(req.body.roll_number || ""), String(req.body.picture_url || ""), JSON.stringify(req.body.extra || {}));
  res.status(201).json({ id: info.lastInsertRowid });
});
app.post("/api/tests/submit", (req, res) => {
  const studentId = safeInt(req.body.student_id), portionId = safeInt(req.body.portion_id);
  const answers = req.body.answers && typeof req.body.answers === "object" ? req.body.answers : {};
  if (!studentId || !portionId || !db.prepare("SELECT id FROM students WHERE id=?").get(studentId)) {
    return res.status(400).json({ error: "Valid student and portion are required." });
  }
  const questions = db.prepare("SELECT id,correct_option,marks FROM questions WHERE portion_id=? ORDER BY id ASC").all(portionId);
  if (!questions.length) return res.status(400).json({ error: "This portion has no questions yet." });
  let correctCount = 0, obtained = 0, total = 0;
  const marked = questions.map(q => {
    const selected = String(answers[q.id] || "").toUpperCase();
    total += Number(q.marks);
    const isCorrect = selected === q.correct_option;
    if (isCorrect) { correctCount++; obtained += Number(q.marks); }
    return { question_id: q.id, selected: ["A","B","C","D"].includes(selected) ? selected : "", correct: q.correct_option, is_correct: isCorrect, marks: Number(q.marks) };
  });
  const wrongCount = questions.length - correctCount;
  const percentage = total ? Math.round((obtained / total) * 10000) / 100 : 0;
  const passed = percentage >= Number(getSetting("passing_percentage", "40"));
  const info = db.prepare(`INSERT INTO results(student_id,portion_id,total_questions,correct_count,wrong_count,total_marks,obtained_marks,percentage,passed,answers_json)
    VALUES(?,?,?,?,?,?,?,?,?,?)`).run(studentId, portionId, questions.length, correctCount, wrongCount, total, obtained, percentage, passed ? 1 : 0, JSON.stringify(marked));
  const student = db.prepare("SELECT name,father_name,class_name,roll_number FROM students WHERE id=?").get(studentId);
  const portion = db.prepare("SELECT title FROM portions WHERE id=?").get(portionId);
  res.status(201).json({ result_id: info.lastInsertRowid, student, portion: portion?.title || "", total_questions: questions.length,
    correct_count: correctCount, wrong_count: wrongCount, total_marks: total, obtained_marks: obtained, percentage, passed,
    submitted_at: new Date().toISOString(), answers: marked });
});
app.get("/api/admin/students", auth, (_req, res) => {
  res.json(db.prepare(`SELECT s.*, (SELECT COUNT(*) FROM results r WHERE r.student_id=s.id) AS test_count
    FROM students s ORDER BY s.id DESC LIMIT 1000`).all());
});
app.get("/api/admin/results", auth, (_req, res) => {
  res.json(db.prepare(`SELECT r.*, s.name AS student_name, s.father_name, s.class_name, s.roll_number, p.title AS portion_title
    FROM results r JOIN students s ON s.id=r.student_id JOIN portions p ON p.id=r.portion_id
    ORDER BY r.id DESC LIMIT 1000`).all());
});
app.get("/api/admin/summary", auth, (_req, res) => {
  res.json({
    sections: db.prepare("SELECT COUNT(*) AS n FROM sections").get().n,
    portions: db.prepare("SELECT COUNT(*) AS n FROM portions").get().n,
    lessons: db.prepare("SELECT COUNT(*) AS n FROM lessons").get().n,
    questions: db.prepare("SELECT COUNT(*) AS n FROM questions").get().n,
    students: db.prepare("SELECT COUNT(*) AS n FROM students").get().n,
    results: db.prepare("SELECT COUNT(*) AS n FROM results").get().n
  });
});
app.get("/api/admin/export", auth, (_req, res) => {
  const data = {
    exported_at: new Date().toISOString(),
    settings: db.prepare("SELECT * FROM settings").all(),
    sections: db.prepare("SELECT * FROM sections").all(),
    portions: db.prepare("SELECT * FROM portions").all(),
    lessons: db.prepare("SELECT * FROM lessons").all(),
    questions: db.prepare("SELECT * FROM questions").all(),
    students: db.prepare("SELECT * FROM students").all(),
    results: db.prepare("SELECT * FROM results").all()
  };
  res.setHeader("Content-Disposition", 'attachment; filename="zexa-backup.json"');
  res.json(data);
});

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "zexa-api" }));

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.json({ name: "Zexa Online Test and Courses System API", status: "running", health: "/api/health" });
});
app.use((err, _req, res, _next) => {
  console.error(err.message || err);
  res.status(400).json({ error: err.message || "Unexpected server error." });
});
app.listen(PORT, () => console.log(`Zexa system running at http://localhost:${PORT}`));
